create table if not exists photos (
  id uuid primary key default gen_random_uuid(),
  album_id uuid references albums(id),
  user_id uuid references users(id),
  id uuid,
  filename text,
  path text,
  mime_type text,
  size integer default 0,
  created_at timestamptz default now(),
  created_at timestamptz default now()
);

create index if not exists idx_photos_album_id on photos(album_id);

create index if not exists idx_photos_user_id on photos(user_id);

create table if not exists albums (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id),
  id uuid,
  name text not null,
  description text,
  created_at timestamptz default now(),
  created_at timestamptz default now()
);

create index if not exists idx_albums_user_id on albums(user_id);

create table if not exists shares (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id),
  id uuid,
  resource_type text,
  resource_id uuid,
  token text,
  permission text,
  expires_at timestamptz,
  created_at timestamptz default now()
);

create index if not exists idx_shares_user_id on shares(user_id);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  id uuid,
  email text not null,
  name text not null,
  created_at timestamptz default now(),
  created_at timestamptz default now()
);