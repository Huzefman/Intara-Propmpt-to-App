-- Intara file uploads (Supabase Storage). Run once in the SQL editor.
insert into storage.buckets (id, name, public)
values ('uploads', 'uploads', true)
on conflict (id) do nothing;

drop policy if exists "uploads public read" on storage.objects;
create policy "uploads public read"
  on storage.objects for select using (bucket_id = 'uploads');

drop policy if exists "uploads anyone can add" on storage.objects;
create policy "uploads anyone can add"
  on storage.objects for insert with check (bucket_id = 'uploads');
