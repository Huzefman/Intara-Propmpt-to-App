# PhotoVault Backend

Run without Supabase (SQLite):

```bash
cd backend
pip install -r requirements.txt
uvicorn server.main:app --reload --port 8000
```

With Supabase: set `SUPABASE_URL` and `SUPABASE_KEY` in `.env`, then same command — db.py swaps to Supabase.

File uploads: run `storage.sql` once in the Supabase SQL editor to create the
`uploads` bucket, then expose the project credentials to the frontend via
`window.__INTARA_ENV__ = { SUPABASE_URL, SUPABASE_ANON_KEY }`. Without it,
uploads persist as local Data URLs per record.
