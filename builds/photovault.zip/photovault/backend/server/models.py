from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Photo(BaseModel):
    id: Optional[str] = None
    album_id: Optional[str] = None
    user_id: Optional[str] = None
    filename: str
    path: str
    mime_type: str
    size: Optional[int] = None
    created_at: datetime

class Album(BaseModel):
    id: Optional[str] = None
    user_id: Optional[str] = None
    name: str
    description: str
    created_at: datetime

class Share(BaseModel):
    id: Optional[str] = None
    user_id: Optional[str] = None
    resource_type: str
    resource_id: str
    token: str
    permission: str
    expires_at: Optional[datetime] = None
    created_at: datetime

class User(BaseModel):
    id: Optional[str] = None
    email: str
    name: str
    created_at: datetime

# App: PhotoVault