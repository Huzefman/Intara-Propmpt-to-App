""" PhotoVault — FastAPI — Intara forged """
import uuid
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from server.db import get_engine, init_db, supabase
from sqlalchemy import text

app = FastAPI(title="PhotoVault")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
init_db()  # ensure SQLite tables exist

def _new_id() -> str:
    return uuid.uuid4().hex[:12]

def _row_or_404(table: str, rid: str) -> dict:
    if supabase:
        try:
            r = supabase.table(table).select("*").eq("id", rid).single().execute()
            if r.data: return r.data
        except Exception: pass
    try:
        with get_engine().connect() as conn:
            r = conn.execute(text("select * from " + table + " where id = :id"), {"id": rid}).mappings().first()
            if r: return dict(r)
    except Exception: pass
    raise HTTPException(404, f"{table} {rid} not found")


# photos — full CRUD (Supabase when env set, else SQLite)
@app.get("/api/photos")
def list_photos():
    if supabase:
        try:
            return supabase.table("photos").select("*").execute().data or []
        except Exception as e: print(e)
    try:
        with get_engine().connect() as conn:
            rows = conn.execute(text("select * from photos")).mappings().all()
            return [dict(r) for r in rows]
    except Exception as e: raise HTTPException(500, str(e))
@app.post("/api/photos")
def create_photos(body: dict):
    body = dict(body or {})
    body.setdefault("id", _new_id())
    if supabase:
        try:
            return supabase.table("photos").insert(body).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            cols = ", ".join(body.keys())
            vals = ", ".join([f":{k}" for k in body.keys()])
            conn.execute(text(f"insert into photos ({cols}) values ({vals})"), body)
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("photos", body["id"])
@app.get("/api/photos/{id}")
def get_photos_by_id(id: str):
    return _row_or_404("photos", id)
@app.put("/api/photos/{id}")
def put_photos(id: str, body: dict):
    _row_or_404("photos", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("photos").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update photos set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("photos", id)
@app.patch("/api/photos/{id}")
def patch_photos(id: str, body: dict):
    _row_or_404("photos", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("photos").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update photos set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("photos", id)
@app.delete("/api/photos/{id}")
def delete_photos(id: str):
    _row_or_404("photos", id)
    if supabase:
        try:
            supabase.table("photos").delete().eq("id", id).execute()
            return {"ok": True}
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            conn.execute(text("delete from photos where id = :id"), {"id": id})
        return {"ok": True}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))

# albums — full CRUD (Supabase when env set, else SQLite)
@app.get("/api/albums")
def list_albums():
    if supabase:
        try:
            return supabase.table("albums").select("*").execute().data or []
        except Exception as e: print(e)
    try:
        with get_engine().connect() as conn:
            rows = conn.execute(text("select * from albums")).mappings().all()
            return [dict(r) for r in rows]
    except Exception as e: raise HTTPException(500, str(e))
@app.post("/api/albums")
def create_albums(body: dict):
    body = dict(body or {})
    body.setdefault("id", _new_id())
    if supabase:
        try:
            return supabase.table("albums").insert(body).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            cols = ", ".join(body.keys())
            vals = ", ".join([f":{k}" for k in body.keys()])
            conn.execute(text(f"insert into albums ({cols}) values ({vals})"), body)
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("albums", body["id"])
@app.get("/api/albums/{id}")
def get_albums_by_id(id: str):
    return _row_or_404("albums", id)
@app.put("/api/albums/{id}")
def put_albums(id: str, body: dict):
    _row_or_404("albums", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("albums").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update albums set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("albums", id)
@app.patch("/api/albums/{id}")
def patch_albums(id: str, body: dict):
    _row_or_404("albums", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("albums").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update albums set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("albums", id)
@app.delete("/api/albums/{id}")
def delete_albums(id: str):
    _row_or_404("albums", id)
    if supabase:
        try:
            supabase.table("albums").delete().eq("id", id).execute()
            return {"ok": True}
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            conn.execute(text("delete from albums where id = :id"), {"id": id})
        return {"ok": True}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))

# shares — full CRUD (Supabase when env set, else SQLite)
@app.get("/api/shares")
def list_shares():
    if supabase:
        try:
            return supabase.table("shares").select("*").execute().data or []
        except Exception as e: print(e)
    try:
        with get_engine().connect() as conn:
            rows = conn.execute(text("select * from shares")).mappings().all()
            return [dict(r) for r in rows]
    except Exception as e: raise HTTPException(500, str(e))
@app.post("/api/shares")
def create_shares(body: dict):
    body = dict(body or {})
    body.setdefault("id", _new_id())
    if supabase:
        try:
            return supabase.table("shares").insert(body).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            cols = ", ".join(body.keys())
            vals = ", ".join([f":{k}" for k in body.keys()])
            conn.execute(text(f"insert into shares ({cols}) values ({vals})"), body)
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("shares", body["id"])
@app.get("/api/shares/{id}")
def get_shares_by_id(id: str):
    return _row_or_404("shares", id)
@app.put("/api/shares/{id}")
def put_shares(id: str, body: dict):
    _row_or_404("shares", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("shares").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update shares set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("shares", id)
@app.patch("/api/shares/{id}")
def patch_shares(id: str, body: dict):
    _row_or_404("shares", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("shares").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update shares set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("shares", id)
@app.delete("/api/shares/{id}")
def delete_shares(id: str):
    _row_or_404("shares", id)
    if supabase:
        try:
            supabase.table("shares").delete().eq("id", id).execute()
            return {"ok": True}
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            conn.execute(text("delete from shares where id = :id"), {"id": id})
        return {"ok": True}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))

# users — full CRUD (Supabase when env set, else SQLite)
@app.get("/api/users")
def list_users():
    if supabase:
        try:
            return supabase.table("users").select("*").execute().data or []
        except Exception as e: print(e)
    try:
        with get_engine().connect() as conn:
            rows = conn.execute(text("select * from users")).mappings().all()
            return [dict(r) for r in rows]
    except Exception as e: raise HTTPException(500, str(e))
@app.post("/api/users")
def create_users(body: dict):
    body = dict(body or {})
    body.setdefault("id", _new_id())
    if supabase:
        try:
            return supabase.table("users").insert(body).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            cols = ", ".join(body.keys())
            vals = ", ".join([f":{k}" for k in body.keys()])
            conn.execute(text(f"insert into users ({cols}) values ({vals})"), body)
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("users", body["id"])
@app.get("/api/users/{id}")
def get_users_by_id(id: str):
    return _row_or_404("users", id)
@app.put("/api/users/{id}")
def put_users(id: str, body: dict):
    _row_or_404("users", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("users").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update users set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("users", id)
@app.patch("/api/users/{id}")
def patch_users(id: str, body: dict):
    _row_or_404("users", id)
    body = {k: v for k, v in dict(body or {}).items() if k != "id"}
    if not body: raise HTTPException(400, "empty update")
    if supabase:
        try:
            return supabase.table("users").update(body).eq("id", id).execute().data[0]
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            sets = ", ".join([f"{k} = :{k}" for k in body.keys()])
            conn.execute(text(f"update users set {sets} where id = :id"), {**body, "id": id})
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))
    return _row_or_404("users", id)
@app.delete("/api/users/{id}")
def delete_users(id: str):
    _row_or_404("users", id)
    if supabase:
        try:
            supabase.table("users").delete().eq("id", id).execute()
            return {"ok": True}
        except Exception as e: print(e)
    try:
        with get_engine().begin() as conn:
            conn.execute(text("delete from users where id = :id"), {"id": id})
        return {"ok": True}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))

@app.get("/health")
def health(): return {"ok": True, "app": "PhotoVault", "db": "supabase" if supabase else "sqlite"}