"""
DB adapter — SQLite default, Supabase when env set.
Single canonical module: import as `from server.db import ...` with cwd=backend/.
"""
import os
from sqlalchemy import create_engine, text

SUPA_URL = os.getenv("SUPABASE_URL", "")
SUPA_KEY = os.getenv("SUPABASE_KEY", "")

# SQLite fallback (no config needed) — lives next to backend/ cwd
engine = create_engine("sqlite:///./app.db", connect_args={"check_same_thread": False})

DDL = """CREATE TABLE IF NOT EXISTS photos (
  id TEXT PRIMARY KEY,
  album_id TEXT REFERENCES albums(id),
  user_id TEXT REFERENCES users(id),
  filename TEXT,
  path TEXT,
  mime_type TEXT,
  size INTEGER DEFAULT 0,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS albums (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  name TEXT,
  description TEXT,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS shares (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  resource_type TEXT,
  resource_id TEXT,
  token TEXT,
  permission TEXT,
  expires_at TEXT,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT,
  name TEXT,
  created_at TEXT
);"""

def get_engine():
    return engine

def init_db():
    if DDL.strip():
        with engine.begin() as conn:
            for stmt in DDL.split(";"):
                stmt = stmt.strip()
                if stmt:
                    conn.execute(text(stmt))

# Supabase client when configured
supabase = None
if SUPA_URL and SUPA_KEY:
    try:
        from supabase import create_client
        supabase = create_client(SUPA_URL, SUPA_KEY)
    except Exception as e:
        print(f"supabase init failed: {e}")
