import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { uploadAttachment, loadLocalAttachments, saveLocalAttachments } from '../lib/upload'
import { getPhotosById, patchPhotosById, deletePhotosById, listPhotos } from '../api'

export default function PhotoDetail() {
  const { id } = useParams()
  const [item, setItem] = useState<any>(null)
  const [form, setForm] = useState<any>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [uploadUrls, setUploadUrls] = useState<string[]>([])
  useEffect(() => { if (id) setUploadUrls(loadLocalAttachments(String(id))) }, [id])


  const load = async () => {
    setLoading(true)
    try {
      const data = await getPhotosById(String(id))
      if (data && !data.error) {
        setItem(data)
        setForm(data)
      } else {
        // fallback to list and find
        const list = await listPhotos()
        const found = Array.isArray(list) ? list.find((x:any)=>String(x.id)===String(id)) : null
        if (found) { setItem(found); setForm(found) }
      }
    } catch {}
    setLoading(false)
  }
  useEffect(() => { if(id) load() }, [id])

  const save = async () => {
    setSaving(true)
    await patchPhotosById(String(id), form)
    setSaving(false)
    load()
  }
  const remove = async () => {
    if (!confirm('Delete this photos?')) return
    await deletePhotosById(String(id))
    window.location.href = '/'
  }

  if (loading) return <div className="glass" style={{ padding: 24, textAlign: 'center' }}>Loading photos…</div>
  if (!item) return <div className="glass" style={{ padding: 24, textAlign: 'center' }}>Not found <Link to="/">Back to PhotoDetail</Link></div>

  return (
    <div style={{ maxWidth: 640, margin: '0 auto' }}>
      <Link to="/" style={{ fontSize: 12, color: 'var(--intara-faint)', textDecoration: 'none' }}>← Back</Link>
      <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 600, marginTop: 8 }}>PhotoDetail — PhotoVault</h2>
      <p style={{ color: 'var(--intara-faint)', fontSize: 12, marginTop: 4 }}>Editing photos #{id} • id, filename, path</p>
      
      <div className="glass" style={{ padding: 16, marginTop: 16, display: 'grid', gap: 12 }}>
        <input placeholder="id" value={form.id || ""} onChange={e=>setForm((s:any)=>({...s, id: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="filename" value={form.filename || ""} onChange={e=>setForm((s:any)=>({...s, filename: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="path" value={form.path || ""} onChange={e=>setForm((s:any)=>({...s, path: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="mime_type" value={form.mime_type || ""} onChange={e=>setForm((s:any)=>({...s, mime_type: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
          <button onClick={save} disabled={saving} className="btn-primary" style={{ flex: 1 }}>{saving ? 'Saving…' : 'Save changes'}</button>
          <button onClick={remove} className="btn-ghost" style={{ color: '#F87171', borderColor: 'rgba(248,113,113,0.2)' }}>Delete</button>
        </div>
      </div>

      <div className="glass" style={{ padding: 14, marginTop: 16 }}>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--intara-faint)', marginBottom: 8 }}>Current data</div>
        <pre className="code-block" style={{ background: 'transparent', border: 'none', padding: 0 }}>{JSON.stringify(item, null, 2)}</pre>
      </div>
<div className="glass" style={{ padding: 14, marginTop: 16 }}>
  <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--intara-faint)', marginBottom: 8 }}>Attachments</div>
  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
    <label className="btn-ghost" style={{ fontSize: 11, cursor: 'pointer', padding: '8px 12px' }}>Choose file
      <input type="file" style={{ display: 'none' }} onChange={async (e:any) => {
        const f = e.target.files && e.target.files[0];
        if (!f || !id) return;
        const url = await uploadAttachment(f);
        const next = [...uploadUrls, url];
        setUploadUrls(next);
        saveLocalAttachments(String(id), next);
      }} />
    </label>
    <span style={{ fontSize: 11, color: 'var(--intara-dim)' }}>{uploadUrls.length ? uploadUrls.length + ' attached' : 'images or documents'}</span>
  </div>
  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }}>
    {uploadUrls.map((u:string, i:number) => (
      u.startsWith('data:image/') || /\.(png|jpe?g|gif|webp|svg)(\?|$)/i.test(u)
        ? <img key={i} src={u} alt={'attachment ' + (i+1)} style={{ width: 72, height: 72, objectFit: 'cover', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)' }} />
        : <a key={i} href={u} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--intara-nebula-light)' }}>file {i+1}</a>
    ))}
  </div>
</div>
    </div>
  )
}
