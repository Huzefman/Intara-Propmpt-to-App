import { useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { listShares, createShares, patchSharesById } from '../api'

export default function Shares() {
  const [items, setItems] = useState<any[]>([])
  const [form, setForm] = useState<any>({})
  const [q, setQ] = useState("")
  const [filter, setFilter] = useState("all")

  const load = () => listShares().then(d => setItems(Array.isArray(d) ? d : [])).catch(()=>{})
  useEffect(() => { load() }, [])

  const create = async () => {
    if (!form.resource_type?.trim?.()) return
    await createShares(form)
    setForm({}); load()
  }

  const toggle = async (id:any, field:string, value:any) => {
    await patchSharesById(id, { [field]: value })
    load()
  }

  const filtered = useMemo(() => {
    let out = items
    if (q) out = out.filter(x => Object.values(x).join(' ').toLowerCase().includes(q.toLowerCase()))
    if (filter === 'active') out = out.filter(x => x.completed || x.published === true || x.status === 'active')
    if (filter === 'done') out = out.filter(x => x.completed === true)
    return out
  }, [items, q, filter])

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 16 }}>
        <div>
          <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>Shares — PhotoVault</h2>
          <p style={{ color: 'var(--intara-faint)', fontSize: 12, marginTop: 4 }}>Manage shares • id, resource_type, resource_id, token</p>
        </div>
        <Link to="/shares" style={{ fontSize: 11, padding: '6px 10px', borderRadius: 999, border: '1px solid rgba(255,255,255,0.06)', textDecoration: 'none', color: 'var(--intara-faint)' }}>/shares</Link>
      </div>

      <div className="glass" style={{ padding: 14, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <input placeholder="Search shares…" value={q} onChange={e=>setQ(e.target.value)} style={{ flex: 1, minWidth: 160, padding: '10px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.03)', color: 'var(--intara-text)' }} />
        <select value={filter} onChange={e=>setFilter(e.target.value)} style={{ padding: '10px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.03)', color: 'var(--intara-text)', fontSize: 12 }}>
          <option value="all">All</option>
          <option value="active">Active</option>
          <option value="done">Done</option>
        </select>

      </div>

      <div className="glass" style={{ padding: 14, marginTop: 12, display: 'grid', gap: 10 }}>
        <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--intara-faint)', marginBottom: 2 }}>Create new share</div>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
        <input placeholder="id" value={form.id || ""} onChange={e=>setForm((s:any)=>({...s, id: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="resource_type" value={form.resource_type || ""} onChange={e=>setForm((s:any)=>({...s, resource_type: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="resource_id" value={form.resource_id || ""} onChange={e=>setForm((s:any)=>({...s, resource_id: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="token" value={form.token || ""} onChange={e=>setForm((s:any)=>({...s, token: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
          <button onClick={create} className="btn-primary" style={{ whiteSpace: 'nowrap' }} >Add share</button>
        </div>
      </div>

      <div style={{ display: 'grid', gap: 10, marginTop: 16 }}>
        {filtered.length ? filtered.map((item:any) => (
          <div key={item.id} className="glass" style={{ padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <Link to={`/shares/${item.id}`} style={{ fontWeight: 600, fontSize: 13, color: 'var(--intara-text)', textDecoration: 'none' }}>{item.id || item.name || item.email || 'Untitled'}</Link>
                <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.id || ""}</span> <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.resource_type || ""}</span> <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.resource_id || ""}</span> <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.token || ""}</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--intara-dim)', marginTop: 4 }}>{item.id ? `#${String(item.id).slice(0,8)}` : ''} resource_type: {item.resource_type}</div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              {item.completed !== undefined && (
                <button onClick={()=>toggle(item.id, 'completed', !item.completed)} style={{ padding: '6px 10px', borderRadius: 999, fontSize: 11, border: '1px solid rgba(255,255,255,0.06)', background: item.completed ? 'rgba(16,185,129,0.12)' : 'transparent', color: item.completed ? '#10B981' : 'var(--intara-faint)'}}>{item.completed ? 'Done' : 'Todo'}</button>
              )}
              <Link to={`/shares/${item.id}`} className="btn-ghost" style={{ padding: '6px 10px', fontSize: 11, textDecoration: 'none' }}>View</Link>
            </div>
          </div>
        )) : (
          <div className="glass" style={{ padding: 32, textAlign: 'center', color: 'var(--intara-faint)' }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>No shares yet</div>
            <div style={{ fontSize: 11, marginTop: 4 }}>Create your first share above — it saves instantly to IndexedDB</div>
          </div>
        )}
      </div>
    </div>
  )
}
