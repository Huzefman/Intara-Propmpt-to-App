import { useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { listPhotos, createPhotos, patchPhotosById } from '../api'

export default function Library() {
  const [items, setItems] = useState<any[]>([])
  const [form, setForm] = useState<any>({})
  const [q, setQ] = useState("")
  const [filter, setFilter] = useState("all")

  const load = () => listPhotos().then(d => setItems(Array.isArray(d) ? d : [])).catch(()=>{})
  useEffect(() => { load() }, [])

  const create = async () => {
    if (!form.filename?.trim?.()) return
    await createPhotos(form)
    setForm({}); load()
  }

  const toggle = async (id:any, field:string, value:any) => {
    await patchPhotosById(id, { [field]: value })
    load()
  }

  const filtered = useMemo(() => {
    let out = items
    if (q) out = out.filter(x => Object.values(x).join(' ').toLowerCase().includes(q.toLowerCase()))
    if (filter === 'active') out = out.filter(x => x.completed || x.published === true || x.status === 'active')
    if (filter === 'done') out = out.filter(x => x.completed === true)
    return out
  }, [items, q, filter])

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 16 }}>
        <div>
          <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>Library — PhotoVault</h2>
          <p style={{ color: 'var(--intara-faint)', fontSize: 12, marginTop: 4 }}>Manage photos • id, filename, path, mime_type</p>
        </div>
        <Link to="/" style={{ fontSize: 11, padding: '6px 10px', borderRadius: 999, border: '1px solid rgba(255,255,255,0.06)', textDecoration: 'none', color: 'var(--intara-faint)' }}>/</Link>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 16 }}>
        <div className="glass" style={{ padding: 14, textAlign: 'center' }}>
          <div style={{ fontSize: 20, fontWeight: 600 }}>{items.length}</div>
          <div style={{ fontSize: 11, color: 'var(--intara-faint)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Total photos</div>
        </div>
        <div className="glass" style={{ padding: 14, textAlign: 'center' }}>
          <div style={{ fontSize: 20, fontWeight: 600, color: 'var(--intara-nebula-light)' }}>{items.filter((x:any)=>x.completed || x.published || x.status==='active').length}</div>
          <div style={{ fontSize: 11, color: 'var(--intara-faint)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Active</div>
        </div>
        <div className="glass" style={{ padding: 14, textAlign: 'center' }}>
          <div style={{ fontSize: 20, fontWeight: 600 }}>{new Set(items.map((x:any)=>x.title||x.name)).size}</div>
          <div style={{ fontSize: 11, color: 'var(--intara-faint)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Unique</div>
        </div>
      </div>
      <div className="glass" style={{ padding: 14, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <input placeholder="Search photos…" value={q} onChange={e=>setQ(e.target.value)} style={{ flex: 1, minWidth: 160, padding: '10px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.03)', color: 'var(--intara-text)' }} />
        <select value={filter} onChange={e=>setFilter(e.target.value)} style={{ padding: '10px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.03)', color: 'var(--intara-text)', fontSize: 12 }}>
          <option value="all">All</option>
          <option value="active">Active</option>
          <option value="done">Done</option>
        </select>

      </div>

      <div className="glass" style={{ padding: 14, marginTop: 12, display: 'grid', gap: 10 }}>
        <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--intara-faint)', marginBottom: 2 }}>Create new photo</div>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
        <input placeholder="id" value={form.id || ""} onChange={e=>setForm((s:any)=>({...s, id: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="filename" value={form.filename || ""} onChange={e=>setForm((s:any)=>({...s, filename: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="path" value={form.path || ""} onChange={e=>setForm((s:any)=>({...s, path: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
        <input placeholder="mime_type" value={form.mime_type || ""} onChange={e=>setForm((s:any)=>({...s, mime_type: e.target.value}))} style={{ flex:1, minWidth:120, padding:"10px 12px", borderRadius:10, border:"1px solid rgba(255,255,255,0.06)", background:"rgba(255,255,255,0.03)", color:"var(--intara-text)" }} />
          <button onClick={create} className="btn-primary" style={{ whiteSpace: 'nowrap' }} >Add photo</button>
        </div>
      </div>

      <div style={{ display: 'grid', gap: 10, marginTop: 16 }}>
        {filtered.length ? filtered.map((item:any) => (
          <div key={item.id} className="glass" style={{ padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <Link to={`/photos/${item.id}`} style={{ fontWeight: 600, fontSize: 13, color: 'var(--intara-text)', textDecoration: 'none' }}>{item.id || item.name || item.email || 'Untitled'}</Link>
                <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.id || ""}</span> <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.filename || ""}</span> <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.path || ""}</span> <span style={{ fontSize:11, color:"var(--intara-faint)"}}>{item.mime_type || ""}</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--intara-dim)', marginTop: 4 }}>{item.id ? `#${String(item.id).slice(0,8)}` : ''} filename: {item.filename}</div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              {item.completed !== undefined && (
                <button onClick={()=>toggle(item.id, 'completed', !item.completed)} style={{ padding: '6px 10px', borderRadius: 999, fontSize: 11, border: '1px solid rgba(255,255,255,0.06)', background: item.completed ? 'rgba(16,185,129,0.12)' : 'transparent', color: item.completed ? '#10B981' : 'var(--intara-faint)'}}>{item.completed ? 'Done' : 'Todo'}</button>
              )}
              <Link to={`/photos/${item.id}`} className="btn-ghost" style={{ padding: '6px 10px', fontSize: 11, textDecoration: 'none' }}>View</Link>
            </div>
          </div>
        )) : (
          <div className="glass" style={{ padding: 32, textAlign: 'center', color: 'var(--intara-faint)' }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>No photos yet</div>
            <div style={{ fontSize: 11, marginTop: 4 }}>Create your first photo above — it saves instantly to IndexedDB</div>
          </div>
        )}
      </div>
    </div>
  )
}
