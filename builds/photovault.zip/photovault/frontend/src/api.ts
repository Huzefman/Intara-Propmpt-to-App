// Intara Frontend — API client (mock vs real) — Sandpack safe
// Canonical: one fn per contract route. Pages import these; do not raw-fetch /api.
const MODE = 'mock'
const API_URL = ''
function baseFetch(path: string, init?: RequestInit) {
  const url = MODE === 'mock' ? path : `${API_URL}${path}`
  return fetch(url, init)
}
const _json = { 'Content-Type': 'application/json' }
export const listPhotos = () => baseFetch('/api/photos').then(r => r.json())
export const createPhotos = (body:any) => baseFetch('/api/photos', {method:'POST', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const getPhotosById = (id:string) => baseFetch(`/api/photos/${id}`).then(r => r.json())
export const putPhotosById = (id:string, body:any) => baseFetch(`/api/photos/${id}`, {method:'PUT', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const patchPhotosById = (id:string, body:any) => baseFetch(`/api/photos/${id}`, {method:'PATCH', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const deletePhotosById = (id:string) => baseFetch(`/api/photos/${id}`, {method:'DELETE'}).then(r => r.json())
export const listAlbums = () => baseFetch('/api/albums').then(r => r.json())
export const createAlbums = (body:any) => baseFetch('/api/albums', {method:'POST', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const getAlbumsById = (id:string) => baseFetch(`/api/albums/${id}`).then(r => r.json())
export const putAlbumsById = (id:string, body:any) => baseFetch(`/api/albums/${id}`, {method:'PUT', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const patchAlbumsById = (id:string, body:any) => baseFetch(`/api/albums/${id}`, {method:'PATCH', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const deleteAlbumsById = (id:string) => baseFetch(`/api/albums/${id}`, {method:'DELETE'}).then(r => r.json())
export const listShares = () => baseFetch('/api/shares').then(r => r.json())
export const createShares = (body:any) => baseFetch('/api/shares', {method:'POST', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const getSharesById = (id:string) => baseFetch(`/api/shares/${id}`).then(r => r.json())
export const putSharesById = (id:string, body:any) => baseFetch(`/api/shares/${id}`, {method:'PUT', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const patchSharesById = (id:string, body:any) => baseFetch(`/api/shares/${id}`, {method:'PATCH', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const deleteSharesById = (id:string) => baseFetch(`/api/shares/${id}`, {method:'DELETE'}).then(r => r.json())
export const listUsers = () => baseFetch('/api/users').then(r => r.json())
export const createUsers = (body:any) => baseFetch('/api/users', {method:'POST', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const getUsersById = (id:string) => baseFetch(`/api/users/${id}`).then(r => r.json())
export const putUsersById = (id:string, body:any) => baseFetch(`/api/users/${id}`, {method:'PUT', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const patchUsersById = (id:string, body:any) => baseFetch(`/api/users/${id}`, {method:'PATCH', headers:_json, body: JSON.stringify(body)}).then(r => r.json())
export const deleteUsersById = (id:string) => baseFetch(`/api/users/${id}`, {method:'DELETE'}).then(r => r.json())
// Preview mock auto-installed via src/mock/server.ts when VITE_API_MODE=mock