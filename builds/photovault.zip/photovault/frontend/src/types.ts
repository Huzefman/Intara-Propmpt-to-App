// Intara — Types
export type Photo = { id: string; id: string; filename: string; path: string; mime_type: string; size: number; created_at: string; album_id: string; user_id: string }
export type Album = { id: string; id: string; name: string; description: string; created_at: string; user_id: string }
export type Share = { id: string; id: string; resource_type: string; resource_id: string; token: string; permission: string; expires_at: string; created_at: string; user_id: string }
export type User = { id: string; id: string; email: string; name: string; created_at: string }