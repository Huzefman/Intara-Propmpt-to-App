// Attachments: Supabase Storage when the host sets window.__INTARA_ENV__
// ({ SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_BUCKET }), otherwise local-only
// Data URLs persisted per record id. Sandpack-safe: no import.meta.
function env(): { url: string; key: string; bucket: string } {
  const w = window as any;
  const e = (w && w.__INTARA_ENV__) || {};
  return {
    url: e.SUPABASE_URL || "",
    key: e.SUPABASE_ANON_KEY || "",
    bucket: e.SUPABASE_BUCKET || "uploads",
  };
}

async function supabaseUpload(file: File): Promise<string | null> {
  try {
    const { url, key, bucket } = env();
    if (!url || !key) return null;
    const { createClient } = await import("@supabase/supabase-js");
    const sb = createClient(url, key);
    const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const path = Date.now() + "-" + safe;
    const up = await sb.storage.from(bucket).upload(path, file);
    if (up.error) return null;
    const pub = sb.storage.from(bucket).getPublicUrl(path);
    return (pub.data && pub.data.publicUrl) || null;
  } catch {
    return null;
  }
}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result || ""));
    r.onerror = () => reject(new Error("read failed"));
    r.readAsDataURL(file);
  });
}

export async function uploadAttachment(file: File): Promise<string> {
  const remote = await supabaseUpload(file);
  if (remote) return remote;
  return readAsDataUrl(file);
}

export function loadLocalAttachments(recordId: string): string[] {
  try {
    const raw = localStorage.getItem("intara-attachments-" + recordId);
    const parsed = JSON.parse(raw || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    const empty: string[] = [];
    return empty;
  }
}

export function saveLocalAttachments(recordId: string, urls: string[]) {
  try {
    localStorage.setItem("intara-attachments-" + recordId, JSON.stringify(urls));
  } catch {}
}
