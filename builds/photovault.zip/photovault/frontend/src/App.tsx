import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import { useEffect } from 'react'
import { Library, AlbumView, PhotoDetail, Upload } from './pages'

export default function App() {
  useEffect(() => {
    // Trial: IndexedDB mock — no backend needed
    import('./mock/server').then(m => m.installMockServer())
    import('./mock/seed').then(m => m.seedPreview())
  }, [])
  return (
    <BrowserRouter>
      <div style={{ minHeight:"100vh", background:"#07070B", color:"#F8FAFC", fontFamily:"Inter, system-ui, sans-serif" }}>
        <nav style={{ display:"flex", gap:8, padding:"16px 20px", borderBottom:"1px solid rgba(255,255,255,0.06)", position:"sticky", top:0, background:"rgba(7,7,11,0.8)", backdropFilter:"blur(16px)", zIndex:10 }}>
          <span style={{ fontFamily:"Space Grotesk", fontWeight:500, letterSpacing:"-0.02em", marginRight:12 }}>PhotoVault</span>
          <Link to="/" style={{ padding:"8px 14px", borderRadius:999, textDecoration:"none", fontSize:12, fontWeight:500, color:"var(--intara-muted)", border:"1px solid transparent" }}>Library</Link>
          <Link to="/albums/:id" style={{ padding:"8px 14px", borderRadius:999, textDecoration:"none", fontSize:12, fontWeight:500, color:"var(--intara-muted)", border:"1px solid transparent" }}>AlbumView</Link>
          <Link to="/photos/:id" style={{ padding:"8px 14px", borderRadius:999, textDecoration:"none", fontSize:12, fontWeight:500, color:"var(--intara-muted)", border:"1px solid transparent" }}>PhotoDetail</Link>
          <Link to="/upload" style={{ padding:"8px 14px", borderRadius:999, textDecoration:"none", fontSize:12, fontWeight:500, color:"var(--intara-muted)", border:"1px solid transparent" }}>Upload</Link>
        </nav>
        <main style={{ maxWidth:820, margin:"0 auto", padding:"24px 20px" }}>
          <Routes>
        <Route path="/" element={<Library />} />
        <Route path="/albums/:id" element={<AlbumView />} />
        <Route path="/photos/:id" element={<PhotoDetail />} />
        <Route path="/upload" element={<Upload />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}
