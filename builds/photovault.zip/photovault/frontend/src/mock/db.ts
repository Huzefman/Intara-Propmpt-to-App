import Dexie from 'dexie'

export class PreviewDB extends Dexie {
  photos!: Dexie.Table<any, string>
  albums!: Dexie.Table<any, string>
  shares!: Dexie.Table<any, string>
  users!: Dexie.Table<any, string>
  constructor() {
    super('intara-preview')
    this.version(1).stores({
    'photos': 'id,filename,path,mime_type,size,created_at,album_id,user_id',
    'albums': 'id,name,description,created_at,user_id',
    'shares': 'id,resource_type,resource_id,token,permission,expires_at,created_at,user_id',
    'users': 'id,email,name,created_at'
    })
  }
}

export const db = new PreviewDB()
