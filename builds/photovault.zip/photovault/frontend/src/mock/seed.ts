import { db } from './db'

export async function seedPreview() {
  const counts = await Promise.all([db.photos.count(), db.albums.count(), db.shares.count(), db.users.count()])
  if (counts.some((c: number) => c > 0)) return
  await db.photos.put({"id": "photos-1", "filename": "Demo filename 1", "path": "Sample 1", "mime_type": "Sample 1", "size": 10, "created_at": "2026-01-01T00:00:00.000Z", "album_id": "albums-2"})
  await db.photos.put({"id": "photos-2", "filename": "Demo filename 2", "path": "Sample 2", "mime_type": "Sample 2", "size": 20, "created_at": "2026-01-01T00:00:00.000Z", "album_id": "albums-3"})
  await db.photos.put({"id": "photos-3", "filename": "Demo filename 3", "path": "Sample 3", "mime_type": "Sample 3", "size": 30, "created_at": "2026-01-01T00:00:00.000Z", "album_id": "albums-1"})
  await db.albums.put({"id": "albums-1", "name": "Demo name 1", "description": "Sample 1", "created_at": "2026-01-01T00:00:00.000Z", "user_id": "users-2"})
  await db.albums.put({"id": "albums-2", "name": "Demo name 2", "description": "Sample 2", "created_at": "2026-01-01T00:00:00.000Z", "user_id": "users-3"})
  await db.albums.put({"id": "albums-3", "name": "Demo name 3", "description": "Sample 3", "created_at": "2026-01-01T00:00:00.000Z", "user_id": "users-1"})
  await db.shares.put({"id": "shares-1", "resource_type": "Sample 1", "resource_id": "val1", "token": "Sample 1", "permission": "Sample 1", "expires_at": "2026-01-01T00:00:00.000Z", "created_at": "2026-01-01T00:00:00.000Z"})
  await db.shares.put({"id": "shares-2", "resource_type": "Sample 2", "resource_id": "val2", "token": "Sample 2", "permission": "Sample 2", "expires_at": "2026-01-01T00:00:00.000Z", "created_at": "2026-01-01T00:00:00.000Z"})
  await db.shares.put({"id": "shares-3", "resource_type": "Sample 3", "resource_id": "val3", "token": "Sample 3", "permission": "Sample 3", "expires_at": "2026-01-01T00:00:00.000Z", "created_at": "2026-01-01T00:00:00.000Z"})
  await db.users.put({"id": "users-1", "email": "demo1@intara.test", "name": "Demo name 1", "created_at": "2026-01-01T00:00:00.000Z"})
  await db.users.put({"id": "users-2", "email": "demo2@intara.test", "name": "Demo name 2", "created_at": "2026-01-01T00:00:00.000Z"})
  await db.users.put({"id": "users-3", "email": "demo3@intara.test", "name": "Demo name 3", "created_at": "2026-01-01T00:00:00.000Z"})
  console.log('intara: seeded', counts)
}
