import { db } from './db'

let patched = false

export function installMockServer() {
  if (patched) return
  patched = true
  const origFetch = window.fetch.bind(window)
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const req = new Request(input, init)
    const url = new URL(req.url, window.location.origin)
    const pathname = url.pathname
    const method = req.method.toUpperCase()
    // only intercept /api/*
    if (!pathname.startsWith('/api/')) return origFetch(req)

    try {
  if (pathname === "/api/photos" && method === "GET") { return Response.json(await db.photos.toArray()) }
  if (pathname === "/api/photos" && method === "POST") { const b = await req.json().catch(()=>({})); if (!b.id) b.id = "photos-" + Math.random().toString(36).slice(2, 10); await db.photos.put(b); return Response.json(await db.photos.get(b.id)) }
  if (pathname.startsWith("/api/photos/") && method === "GET") { const id = String(pathname.split("/").pop()); const row = await db.photos.get(id); return row ? Response.json(row) : Response.json({error:"not found"}, {status:404}) }
  if (pathname.startsWith("/api/photos/") && method === "PUT") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); b.id = id; await db.photos.put(b); return Response.json(await db.photos.get(id)) }
  if (pathname.startsWith("/api/photos/") && method === "PATCH") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); await db.photos.update(id, b); return Response.json(await db.photos.get(id)) }
  if (pathname.startsWith("/api/photos/") && method === "DELETE") { const id = String(pathname.split("/").pop()); await db.photos.delete(id); return Response.json({ok:true}) }
  if (pathname === "/api/albums" && method === "GET") { return Response.json(await db.albums.toArray()) }
  if (pathname === "/api/albums" && method === "POST") { const b = await req.json().catch(()=>({})); if (!b.id) b.id = "albums-" + Math.random().toString(36).slice(2, 10); await db.albums.put(b); return Response.json(await db.albums.get(b.id)) }
  if (pathname.startsWith("/api/albums/") && method === "GET") { const id = String(pathname.split("/").pop()); const row = await db.albums.get(id); return row ? Response.json(row) : Response.json({error:"not found"}, {status:404}) }
  if (pathname.startsWith("/api/albums/") && method === "PUT") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); b.id = id; await db.albums.put(b); return Response.json(await db.albums.get(id)) }
  if (pathname.startsWith("/api/albums/") && method === "PATCH") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); await db.albums.update(id, b); return Response.json(await db.albums.get(id)) }
  if (pathname.startsWith("/api/albums/") && method === "DELETE") { const id = String(pathname.split("/").pop()); await db.albums.delete(id); return Response.json({ok:true}) }
  if (pathname === "/api/shares" && method === "GET") { return Response.json(await db.shares.toArray()) }
  if (pathname === "/api/shares" && method === "POST") { const b = await req.json().catch(()=>({})); if (!b.id) b.id = "shares-" + Math.random().toString(36).slice(2, 10); await db.shares.put(b); return Response.json(await db.shares.get(b.id)) }
  if (pathname.startsWith("/api/shares/") && method === "GET") { const id = String(pathname.split("/").pop()); const row = await db.shares.get(id); return row ? Response.json(row) : Response.json({error:"not found"}, {status:404}) }
  if (pathname.startsWith("/api/shares/") && method === "PUT") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); b.id = id; await db.shares.put(b); return Response.json(await db.shares.get(id)) }
  if (pathname.startsWith("/api/shares/") && method === "PATCH") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); await db.shares.update(id, b); return Response.json(await db.shares.get(id)) }
  if (pathname.startsWith("/api/shares/") && method === "DELETE") { const id = String(pathname.split("/").pop()); await db.shares.delete(id); return Response.json({ok:true}) }
  if (pathname === "/api/users" && method === "GET") { return Response.json(await db.users.toArray()) }
  if (pathname === "/api/users" && method === "POST") { const b = await req.json().catch(()=>({})); if (!b.id) b.id = "users-" + Math.random().toString(36).slice(2, 10); await db.users.put(b); return Response.json(await db.users.get(b.id)) }
  if (pathname.startsWith("/api/users/") && method === "GET") { const id = String(pathname.split("/").pop()); const row = await db.users.get(id); return row ? Response.json(row) : Response.json({error:"not found"}, {status:404}) }
  if (pathname.startsWith("/api/users/") && method === "PUT") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); b.id = id; await db.users.put(b); return Response.json(await db.users.get(id)) }
  if (pathname.startsWith("/api/users/") && method === "PATCH") { const id = String(pathname.split("/").pop()); const b = await req.json().catch(()=>({})); await db.users.update(id, b); return Response.json(await db.users.get(id)) }
  if (pathname.startsWith("/api/users/") && method === "DELETE") { const id = String(pathname.split("/").pop()); await db.users.delete(id); return Response.json({ok:true}) }
    } catch (e) {
      console.error('mock server error', e)
      return Response.json({ error: String(e) }, { status: 500 })
    }
    // fallthrough to real fetch if no mock matched
    return origFetch(req)
  }
  console.log('intara: mock server installed', 24 + ' routes')
}
