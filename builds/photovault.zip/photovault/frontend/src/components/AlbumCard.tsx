export function AlbumCard({ item, onSelect }: { item: any, onSelect?: (id:any)=>void }) {
  return (
    <div className="glass" style={{ padding: 14, cursor: onSelect ? 'pointer' : 'default' }} onClick={()=> onSelect?.(item.id)}>
      <div style={{ fontWeight: 600, fontSize: 13 }}>{item.title || item.name || item.email || 'albums'} </div>
      <div style={{ display: 'grid', gap: 4, marginTop: 8 }}>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>id:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.id ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>name:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.name ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>description:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.description ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>created_at:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.created_at ?? "")}</span></div>
      </div>
    </div>
  )
}
