export function ShareCard({ item, onSelect }: { item: any, onSelect?: (id:any)=>void }) {
  return (
    <div className="glass" style={{ padding: 14, cursor: onSelect ? 'pointer' : 'default' }} onClick={()=> onSelect?.(item.id)}>
      <div style={{ fontWeight: 600, fontSize: 13 }}>{item.title || item.name || item.email || 'shares'} </div>
      <div style={{ display: 'grid', gap: 4, marginTop: 8 }}>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>id:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.id ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>resource_type:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.resource_type ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>resource_id:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.resource_id ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>token:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.token ?? "")}</span></div>
      </div>
    </div>
  )
}
