export function PhotoCard({ item, onSelect }: { item: any, onSelect?: (id:any)=>void }) {
  return (
    <div className="glass" style={{ padding: 14, cursor: onSelect ? 'pointer' : 'default' }} onClick={()=> onSelect?.(item.id)}>
      <div style={{ fontWeight: 600, fontSize: 13 }}>{item.title || item.name || item.email || 'photos'} </div>
      <div style={{ display: 'grid', gap: 4, marginTop: 8 }}>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>id:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.id ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>filename:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.filename ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>path:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.path ?? "")}</span></div>
      <div style={{ fontSize: 11 }}><span style={{ color: "var(--intara-faint)" }}>mime_type:</span> <span style={{ color: "var(--intara-text)", fontWeight: 500 }}>{String(item.mime_type ?? "")}</span></div>
      </div>
    </div>
  )
}
