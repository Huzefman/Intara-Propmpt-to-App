# PhotoVault — Intara deterministic build

> Your memories, secured and shared
> Wish: "a photo vault with uploads"
> Built from plan with deterministic templates (no LLM variance) + file-upload component.

## Run Frontend
```bash
cd frontend
npm install
npm run dev
```

## Run Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

## Tables
- **photos**: id:uuid, filename:text, path:text, mime_type:text, size:integer, created_at:timestamp
- **albums**: id:uuid, name:text, description:text, created_at:timestamp, user_id:uuid
- **shares**: id:uuid, resource_type:text, resource_id:uuid, token:text, permission:text, expires_at:timestamp
- **users**: id:uuid, email:text, name:text, created_at:timestamp

## Features
- Attachments on detail pages (src/lib/upload.ts; Supabase Storage via window.__INTARA_ENV__, Data-URL fallback in trial)
- storage.sql: run once in Supabase SQL editor for the uploads bucket
- Trial: Dexie mock (src/mock/*) with seeded demo rows

## Validation
- validate_tsx / ast.parse / import-consistency: clean
- Backend gates (import + CRUD matrix incl. FK round-trips): GREEN
